/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.utfpr.cm.pi.daos;

import br.edu.utfpr.cm.pi.entidades.OrdemCompra;

/**
 *
 * @author Paulo Azevedo
 */
public class DaoOrdemCompra extends DaoGenerics<OrdemCompra> {
    public DaoOrdemCompra() {
        super(OrdemCompra.class);
    }

}
