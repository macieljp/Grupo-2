/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.utfpr.cm.pi.daos;

import br.edu.utfpr.cm.pi.entidades.Cidade;

/**
 *
 * @author paulo
 */
public class DaoCidade extends DaoGenerics<Cidade>{
    public DaoCidade() {
        super(Cidade.class);
    }
}
